//
//  bookCell.swift
//  Bracker
//
//  Created by Annie Fu on 11/19/23.
//
// Description: used to create a custom class for the collection view cell

import UIKit

class bookCell: UICollectionViewCell {
    
    @IBOutlet weak var bookImage: UIImageView!
    
}
